# DiSCover
An android information and social network application with Firebase(in progress)


2017/10/19 18:19 Log in with Google account; Log out on home page.