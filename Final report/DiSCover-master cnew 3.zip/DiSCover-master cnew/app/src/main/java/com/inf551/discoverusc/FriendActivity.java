package com.inf551.discoverusc;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FriendActivity extends AppCompatActivity implements FriendAdapter.MyAdapterOnClickHandler, ChatListAdapter.MyAdapterOnClickHandler {
    final String TAG = getClass().getSimpleName();
    FirebaseDatabase database;
    DatabaseReference myRef;
    private ValueEventListener mValueEventListener;

    DatabaseReference friendSearchRef;
    private ValueEventListener mFriendSearchEventListener;

    DatabaseReference chatListRef;
    private ValueEventListener mChatListEventListener;


    EditText etSearch;
    ImageView ivMain;
    TextView tvName;
    String searchEmail;
    RelativeLayout profileView;
    String stImage;
    String stName;
    String stUid;
    String stChatKey;
    ProgressBar imageProgressBar;
    Button btnAdd;
    String stMyUid;
    String stMyIamage;
    private RecyclerView mRecyclerView;
    private FriendAdapter mFriendAdapter;
    private ChatListAdapter mChatListAdapter;
    private LinearLayoutManager mLayoutManager;
    ArrayList<FriendData> friendDataArrayList;
    ArrayList<ChatListData> chatListDataArrayList;
    ArrayList<String> chatKeyList;
    LinearLayout searchLayout;
    Boolean friendCheck = false;
    String stListCheck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend);
        database = FirebaseDatabase.getInstance();
        profileView = (RelativeLayout) findViewById(R.id.profileView);
        etSearch = (EditText)findViewById(R.id.etSearch);
        ivMain = (ImageView) findViewById(R.id.ivMain);
        tvName = (TextView)findViewById(R.id.tvName);
        imageProgressBar = (ProgressBar) findViewById(R.id.imageProgressBar);
        btnAdd = (Button) findViewById(R.id.btnAdd);

        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        stMyUid = sharedPref.getString("myId", "");
        stMyIamage = sharedPref.getString("myImage", "");

        //uid : firebase에 저장된 유저의 id
        //stMyImage : firebase에 저장된 유저의 image url

        searchLayout = (LinearLayout)findViewById(R.id.searchLayout);

        mRecyclerView = (RecyclerView) findViewById(R.id.rvFriend);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);

        mRecyclerView.setLayoutManager(mLayoutManager);

        chatKeyList = new ArrayList<>();
        showFriendList();

        //search에서 친구 이메일을 입력하고, 맞는 이메일이 출력될 시 해당 유저의 프로필 화면이 나옵니다
        //이때 버튼 btnAdd가 보이며 btnAdd를 클릭시 친구추가를 진행합니다
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkFriendAdded();
                //친구추가 하기 위해 add to friends를 클릭하면 호출 됩니다
                // 내가 친구에게 추가 되었는 지를 체크 합니다
            }
        });

        Button btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileView.setVisibility(View.GONE);
                //친구 찾기로 불러온 프로필 화면 종료

            }
        });

    }

    public void searchButtonClicked(View view) {


        searchEmail = etSearch.getText().toString();
        if(TextUtils.isEmpty(searchEmail)){
            Toast.makeText(this, "Email Required", Toast.LENGTH_SHORT).show();
        } else{
            searchPeople();
            etSearch.setText("");
            //Search 버튼이 클릭 돼면 해당 이메일을 가진 유저를 검색합니다
        }
    }
    public void searchPeople(){
        if( mFriendSearchEventListener != null){
            friendSearchRef.removeEventListener(mFriendSearchEventListener);
        }
        //이벤트 리스너를 따로 정의 해주어 database reference에 연결해 주는 이유는 start stop 시 관리를 수동으로 해주기 편하기 때문입니다
        //예를 보여드리기 위해 작성한 것이며 필요 없을 시 따라 안하셔도 됩니다
        friendSearchRef = database.getReference("Users");
           if(mFriendSearchEventListener == null){
               mFriendSearchEventListener =  new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    List<String> noMathedUserList = new ArrayList<>();
                    for(DataSnapshot userSnapshot: dataSnapshot.getChildren()){
                        //firebase database 유저 정보에 입력된 이메일을 검샙합니다
                        if(userSnapshot.child("email").getValue() != null){
                            String findEmail = userSnapshot.child("email").getValue().toString();
                            //for 구문으로 인해 하나씩 불러와지는 email이 searchEmail과 같은 지 검색합니다
                            noMathedUserList.add(findEmail);
                            //for 구문이 끝난 후 noMathcedUserList에 저장된 이메일을 통해, 관련 이메일이 없는 지 비교 하기 위해 해당 리스트에 저장합니다
                            if(!searchEmail.equals(findEmail)) {
                                //현재 항목에서 해당 유저가 없다는 알림을 띄울 시 for 구문으로 인해 반복적으로 toast가 떠오릅니다
                            } else {
                                stImage = userSnapshot.child("image").getValue().toString();
                                stName = userSnapshot.child("name").getValue().toString();
                                stUid = userSnapshot.child("uid").getValue().toString();
                                Log.d(TAG, "findEmail : "+findEmail+", image : "+stImage);
                                if(stUid.equals(stMyUid)){
                                    Toast.makeText(FriendActivity.this,"That's me!", Toast.LENGTH_SHORT).show();
                                } else {
                                    checkFriend();
                                    //유저가 데이터 상에 존재할 경우 현재 친구여부인지를 체크합니다
                                }
                            }
                        }
                    }
                    if(!noMathedUserList.contains(searchEmail) && noMathedUserList.size() != 0){
                        //리스트에 searchEmail이 없을 경우 해당 유저가 없다는 알림을 듸웁니다
                        Toast.makeText(FriendActivity.this,"No user with that email", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            };
    }

       friendSearchRef.addListenerForSingleValueEvent(mFriendSearchEventListener);
}


    public void showSearchedUser() {
        //glide가 picasso보다 퍼포먼스가 좋기 때문에 개인적으로 선호합니다
        imageProgressBar.setVisibility(View.VISIBLE);
        Glide.with(this)
                .load(stImage)
                .apply(new RequestOptions()
                        .placeholder(R.mipmap.default_image))
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        imageProgressBar.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        imageProgressBar.setVisibility(View.GONE);
                        return false;
                    }
                })
                .into(ivMain);

        tvName.setText(stName);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.firend_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_friend){
            showFriendList();
        } else if (item.getItemId() == R.id.action_chat){
            showChatList();

        } else if(item.getItemId() == R.id.action_block){
            Intent in = new Intent(this, BlockActivity.class);
            startActivity(in);
        }

        return super.onOptionsItemSelected(item);
    }


    public void showFriendList(){

        //친구 목록을 불러오기 위한 메소드 입니다
        //검색창을 보여주고 apdater를 friendadapter로 연결해 줍니다
        searchLayout.setVisibility(View.VISIBLE);
        friendDataArrayList = new ArrayList<>();

        mFriendAdapter = new FriendAdapter(this, this, friendDataArrayList);
        mRecyclerView.setAdapter(mFriendAdapter);

        //recyclerview adapter에 firebase에서 가져온 친구 목록을 추가해주기 위한 기능을 아래 메소드에서 수행합니다
        showFriends();

    }

    public void showChatList(){
        //채팅 목록을 불러오기 위한 메소드 입니다
        //검색창을 숨기고 apdater를 chat list adapter로 연결해 줍니다

        searchLayout.setVisibility(View.GONE);
        chatListDataArrayList = new ArrayList<>();

        mChatListAdapter = new ChatListAdapter(this, this, chatListDataArrayList, stMyIamage);
        mRecyclerView.setAdapter(mChatListAdapter);
        //recyclerview adapter에 firebase에서 가져온 채팅 리스트를 추가해주기 위한 기능을 아래 메소드에서 수행합니다
        showChats();

    }

    public void checkFriend(){
        DatabaseReference friendRef = database.getReference("friends").child(stMyUid);
        friendRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.hasChild(stUid)) {
                    Log.d(TAG, "Ok Succeeded : "+dataSnapshot.getValue().toString());

                    //datasnapshow.haschild로 친구 uid의 데이터베이스에 나의 uid가 있는 지 검색했습니다
                    //있을 경우 이미 친구입니다
                    friendCheck = true;
                    Toast.makeText(FriendActivity.this, "Already in friend list", Toast.LENGTH_SHORT).show();
                } else {
                    if(!friendCheck){
                        profileView.setVisibility(View.VISIBLE);
                        //친구아 아닐 경우 친구 프로필이 눈에 보여집니다
                        showSearchedUser();

                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    public void checkFriendAdded(){
        //내가 친구에게 추가되었는 지 확인합니다
        //채팅 데이터의 경우 chat key라고 명명한 고유의 id 값이 있습니다
        //친구들의 경우 각각 친구와의 채팅을 위한 하나의 chat key를 공유합니다
        DatabaseReference friendRef = database.getReference("friends").child(stUid);
        friendRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.hasChild(stMyUid)) {
                    //내가 이미 친구에게 추가되었을 경우 친구가 나를 위해 만든 chat key를 가져옵니다
                    stChatKey = dataSnapshot.child(stMyUid).child("chatKey").getValue().toString();
                    okPeople(stChatKey);
                } else {
                    //그렇지 않을 경우 chat key를 생성합니다
                    DatabaseReference chatRef = database.getReference();
                    stChatKey = chatRef.child("chat").push().getKey();
                    okPeople(stChatKey);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    public void okPeople(String stChatKey){
        //친구 데이터를 친구 목록에 업데이트 합니다.
        //이제 리스트에 해당 친구 목록이 검색 됩니다.

        DatabaseReference updateRef = database.getReference();
        HashMap<String, Object> friendInfo = new HashMap<>();
        friendInfo.put("image", stImage);
        friendInfo.put("name", stName);
        friendInfo.put("ok", "requested");
        friendInfo.put("uid", stUid);
        friendInfo.put("chatKey", stChatKey);

        updateRef.child("friends").child(stMyUid).child(stUid).setValue(friendInfo);
        updateRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d(TAG, "Ok Succeeded");
                //listener value를 통해 데이터가 변경 되었는 지 콜백을 받아 확인합니다
                //친구 추가가 성공했음을 토스트로 알립니다
                Toast.makeText(FriendActivity.this, "Friend added successfully", Toast.LENGTH_SHORT).show();
                profileView.setVisibility(View.GONE);
                //친구 리스트를 다시 불러와 화면에 추가된 친구가 나오게 합니다
                showFriendList();

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                profileView.setVisibility(View.GONE);
            }
        });
    }

    public void showFriends(){


        stListCheck = "friend";
        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("listCheck", stListCheck);
        editor.apply();

        //intent 를 통해서 다른 액티비티를 호출하고 돌아왔을 때 기존에 화면에 보였던 list를 호출하기 위해 sharedpreference에 저장합니다

        if( mValueEventListener != null){
            myRef.removeEventListener(mValueEventListener);
        }
        myRef = database.getReference("friends").child(stMyUid);
            //firebase 친구 데이터에서 나의 id 밑으로 저장된 친구 목록을 검색 합니다

            if(mValueEventListener == null){
                mValueEventListener =  new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        friendDataArrayList.clear();
                        for (DataSnapshot friendData : dataSnapshot.getChildren()) {

                            Log.d(TAG, "friendDataData" + friendData.getValue().toString());

                            String stOk = friendData.child("ok").getValue().toString();
                            //friend가 나를 차단했는 지 검색합니다
                            //ok 항목에 blocked라고 되어있으면 차단이 된 것 입니다

                            Log.d(TAG, "friend blocekd or not : "+stOk);
                            if(!stOk.equals("blocked")){
                                //block 하지 않은 친구 데이터들만 FriendData 클래스에 저장합니다
                                FriendData model = friendData.getValue(FriendData.class);
                                friendDataArrayList.add(model);
                            }
                        }
                        Log.d(TAG,"downLoadFinished");

                        //저장한 리스트를 어댑터에 연결해 줍니다
                        //어댑터에서는 swapData 메소드를 만들어 리사이클러뷰에 새로운 항목이 보이게 변경합니다
                        mFriendAdapter.swapData(friendDataArrayList);
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                };
            }
            myRef.addListenerForSingleValueEvent(mValueEventListener);
    }

    public void showChats(){
        stListCheck = "chat";
        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("listCheck", stListCheck);
        editor.apply();

        //intent 를 통해서 다른 액티비티를 호출하고 돌아왔을 때 기존에 화면에 보였던 list를 호출하기 위해 sharedpreference에 저장합니다


        if( mChatListEventListener != null){
            chatListRef.removeEventListener(mChatListEventListener);
        }
        chatListRef = database.getReference("chat");

        if(mChatListEventListener == null){
            mChatListEventListener =  new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    chatListDataArrayList.clear();
                    for (DataSnapshot allData : dataSnapshot.getChildren()) {
//                        Log.d(TAG, "chatUserData" + allData.child("chatUsers").getValue().toString() + ", count : " + allData.getChildrenCount());
                        //채팅 리스트에 경우, 리스트당 유저가 2명도 되고 그 이상되 될 수 있습니다
                        //때문에 이름 이미지 키 값을 저장하기 위한 list를 설정해 줍니다

                        List<String> chatUserNameList = new ArrayList<>();
                        List<String> chatUserImageList = new ArrayList<>();
                        List<String> chatUserKeyList = new ArrayList<>();
                        String stLastText = "";
                        String stLastDate = "";
                        for (DataSnapshot userData : allData.child("chatUsers").getChildren()) {
                            Log.d(TAG, "chatUserData get Key : " + userData.getKey());
                            Log.d(TAG, "chatUserDataName" + userData.child("name").getValue().toString());

                            //firebase database에 있는 chat 밑에 있는 하위 값 중 chatusers 항목을 검색합니다
                            //for 구문이 실행될 때마다 리스트에 각각의 항목이 저장 됩니다
                            chatUserKeyList.add(userData.getKey());
                            chatUserNameList.add(userData.child("name").getValue().toString());
                            chatUserImageList.add(userData.child("image").getValue().toString());
                            if(allData.hasChild("lastMessage")){
                                //lastmessage는 채팅창에서 마지막으로 입력된 메세지입니다
                                //채팅 리스트 항목에 보여지게 됩니다
                                stLastText = allData.child("lastMessage").child("lastText").getValue().toString();
                                stLastDate = allData.child("lastMessage").child("lastDate").getValue().toString();
                            }

                        }
                        if(chatUserNameList.size() != 0){
                            Log.d(TAG, chatUserNameList.toString());
                            Log.d(TAG, chatUserKeyList.toString());
                            if(chatUserKeyList.contains(stMyUid)){
                                //chatuser 키 리스트에 나의 유저아이디가 있을경우 내가 속한 채팅 그룹 입니다
                                //이 경우 chat list data에 관련 내용을 저장합니다
                                ChatListData data = new ChatListData();
                                data.setLastDate(stLastDate);
                                data.setLastText(stLastText);
                                data.setNames(chatUserNameList);
                                data.setImages(chatUserImageList);
                                data.setChatKey(allData.getKey());
                                chatListDataArrayList.add(data);
                            }
                        }

                    }

                    mChatListAdapter.swapData(chatListDataArrayList);
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            };
        }
        chatListRef.addListenerForSingleValueEvent(mChatListEventListener);
    }


    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    protected void onResume() {
        super.onResume();
        //friend인지 chat list 인지 확인하여 resume시 호출 합니다
        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        stListCheck = sharedPref.getString("listCheck", "");
        if(stListCheck.equals("friend")){
            showFriendList();
        } else {
            showChatList();
        }


    }

    @Override
    public void onClick(String photoUrl, final ArrayList<FriendData> modelArrayList, final int adapterPosition) {

        //friend list의 항목이 클릭되었습니다

        final String stFriendUid = modelArrayList.get(adapterPosition).getUid();
        DatabaseReference blockRef = database.getReference("friends").child(stFriendUid);
        blockRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d(TAG, "Ok Succeeded");
                if(dataSnapshot.hasChild(stMyUid)){
                    //block 여부를 체크하여 채팅 액티비티로 intent 합니다
                    String stOk = dataSnapshot.child(stMyUid).child("ok").getValue().toString();
                    Log.d(TAG, "Your friend added you : "+stOk);
                    if(stOk.equals("blocked")){
                        Toast.makeText(FriendActivity.this, "Chat Request Denied", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent in = new Intent(FriendActivity.this, ChatActivity.class);
                        in.putExtra("dataName", "friend");
                        in.putExtra("data", modelArrayList);
                        in.putExtra("position", adapterPosition);
                        startActivity(in);
                    }

                } else {
                    Intent in = new Intent(FriendActivity.this, ChatActivity.class);
                    in.putExtra("dataName", "friend");
                    in.putExtra("data", modelArrayList);
                    in.putExtra("position", adapterPosition);
                    startActivity(in);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                profileView.setVisibility(View.GONE);
            }
        });

    }



    @Override
    public void onChatListClick(String photoUrl, ArrayList<ChatListData> modelArrayList, int adapterPosition) {
        //chat list 항목이 클릭되었습니다 chat activity로 intent 합니다
        Intent in = new Intent(this, ChatActivity.class);
        in.putExtra("dataName", "chatList");
        in.putExtra("data", modelArrayList);
        in.putExtra("position", adapterPosition);
        startActivity(in);
    }



}
