package com.inf551.discoverusc;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

/**
 * Created by idahan on 2017. 9. 9..
 */

public class BlockAdapter extends RecyclerView.Adapter<BlockAdapter.ViewHolder> {

    private Context context;
    ArrayList<FriendData> modelArrayList;
    private MyAdapterOnClickHandler mClickHandler;


    /**
     * The interface that receives onClick messages.
     */
    public interface MyAdapterOnClickHandler {
        void onClick(String photoUrl, ArrayList<FriendData> modelArrayList, int adapterPosition);
    }

    /**
     * Creates a ForecastAdapter.
     *
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */
    public BlockAdapter(MyAdapterOnClickHandler clickHandler, Context context, ArrayList<FriendData> modelArrayList) {
        mClickHandler = clickHandler;
        this.modelArrayList = modelArrayList;
        this.context = context;

    }

    /**
     * Cache of the children views for a forecast list item.
     */


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView ivImage;

        public TextView tvName;
        public TextView tvDate;
        public TextView tvMessage;

        public ViewHolder(View v) {
            super(v);
            ivImage = (ImageView) v.findViewById(R.id.ivImage);
            tvName = (TextView) v.findViewById(R.id.tvName);
            tvDate = (TextView) v.findViewById(R.id.tvDate);
            tvMessage = (TextView) v.findViewById(R.id.tvMessage);
            v.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            String stPhotoUrl = modelArrayList.get(adapterPosition).getImage();

            mClickHandler.onClick(stPhotoUrl, modelArrayList, adapterPosition);

        }
    }
    @Override
    public BlockAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                      int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_friend_list, parent, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {



        String stPhotoUrl =modelArrayList.get(position).getImage();

        Glide.with(context)
                .load(stPhotoUrl)
                .apply(RequestOptions.circleCropTransform())
                .into(holder.ivImage);

        holder.tvName.setText(modelArrayList.get(position).getName());


    }
    @Override
    public int getItemCount() {
        if (null == modelArrayList) return 0;
            return modelArrayList.size();
    }

    public void swapData(ArrayList<FriendData> arrayList) {

        modelArrayList = arrayList;
        notifyDataSetChanged();
    }



}
