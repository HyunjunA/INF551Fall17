package com.inf551.discoverusc;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BlockActivity extends AppCompatActivity implements BlockAdapter.MyAdapterOnClickHandler {
    final String TAG = getClass().getSimpleName();
    FirebaseDatabase database;
    DatabaseReference myRef;
    private ValueEventListener mValueEventListener;

    String stMyUid;
    private RecyclerView mRecyclerView;
    private BlockAdapter mBlockAdapter;
    private LinearLayoutManager mLayoutManager;
    ArrayList<FriendData> friendDataArrayList;
    ArrayList<String> chatKeyList;
    String stChatKey;

    List<String> chatUserNameList;
    List<String> chatUserImageList;
    List<String> chatUserIdList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_block);

        database = FirebaseDatabase.getInstance();
        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        stMyUid = sharedPref.getString("myId", "");
        Log.d(TAG, "My id: "+stMyUid);


        mRecyclerView = (RecyclerView) findViewById(R.id.rvFriend);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);

        mRecyclerView.setLayoutManager(mLayoutManager);

        showFriendList();

    }
    public void showFriendList(){
        friendDataArrayList = new ArrayList<>();

        mBlockAdapter = new BlockAdapter(this, this, friendDataArrayList);
        mRecyclerView.setAdapter(mBlockAdapter);

        showFriends();
        //친구 목록을 보여줍니다

    }
    public void showFriends(){

        if( mValueEventListener != null){
            myRef.removeEventListener(mValueEventListener);
        }

        myRef = database.getReference("friends").child(stMyUid);

        if(mValueEventListener == null){
            mValueEventListener =  new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    friendDataArrayList.clear();
                    for (DataSnapshot friendData : dataSnapshot.getChildren()) {
                        Log.d(TAG, "friendDataData" + friendData.getValue().toString());
                        FriendData model = friendData.getValue(FriendData.class);
                        friendDataArrayList.add(model);

                    }
                    Log.d(TAG,"downLoadFinished");
                    if (!dataSnapshot.exists()){
                        Log.d(TAG,"noData");
                        Toast.makeText(BlockActivity.this, "You have no friend", Toast.LENGTH_SHORT).show();
                    }

                    mBlockAdapter.swapData(friendDataArrayList);
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {



                }
            };
        }
        myRef.addListenerForSingleValueEvent(mValueEventListener);
    }

    @Override
    public void onClick(String photoUrl, ArrayList<FriendData> modelArrayList, int adapterPosition) {

        //친구 목록을 클릭하면 해당 친구의 ok 항목을 blocekd로 업데이트합니다
        //이제 이 친구는 나를 초대할 수 없습니다
        String stFriendKey = modelArrayList.get(adapterPosition).getUid();
        myRef = database.getReference("friends").child(stMyUid).child(stFriendKey);
        myRef.child("ok").setValue("blocked");
        Toast.makeText(this, "Friend "+modelArrayList.get(adapterPosition).getName()+ " Blocked", Toast.LENGTH_SHORT).show();
        finish();

    }
}
