package com.inf551.discoverusc;



public class Recommendation {
    private String title,description, image, username,category;
    private Float rating; //same with the Key name in Firebase

    //Command + N
    public Recommendation(){
        //without this app may crush
    }

    public Recommendation(String title, String description, String image, String username, String category, Float rating) {
        this.title = title;
        this.description = description;
        this.image = image;
        this.username = username;
        this.category = category;
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Float getRating(){
        return rating;
    }
    public void setRating(Float rating){
        this.rating = rating;
    }

    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
