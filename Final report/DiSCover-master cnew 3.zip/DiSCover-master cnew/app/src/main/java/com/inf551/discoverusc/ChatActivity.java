package com.inf551.discoverusc;

/**
 * Created by User on 11/3/2017.
 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class ChatActivity extends AppCompatActivity {
    String TAG = getClass().getSimpleName();
    private EditText editMessage;
    FirebaseDatabase database;
    DatabaseReference myRef;
    DatabaseReference exitRef;
    DatabaseReference lastTextRef;

    String stChatKey;
    int inPosition;
    String stMyUid;
    String stMyImage;
    String stMyName;
    String stFriendUid;
    String stFriendImage;
    String stFriendName;
    RecyclerView rvChat;
    private ArrayList<ChatData> mChatData;
    private ChatAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        editMessage =(EditText) findViewById(R.id.editMessageE);


        /*mAuthListner= new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser()==null){
                    startActivity(new Intent(MainActivity.this.RegisterActivity.class));
                }
            }
        };*/
        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        stMyUid = sharedPref.getString("myId", "");
        stMyImage = sharedPref.getString("myImage", "");
        stMyName = sharedPref.getString("myName", "");

        Intent in = getIntent();
        String stDataName = in.getStringExtra("dataName");
        if (stDataName.equals("friend")){
            ArrayList<FriendData> modelArrayList = in.getParcelableArrayListExtra("data");
            inPosition = in.getIntExtra("position", 0);
            stChatKey = modelArrayList.get(inPosition).getChatKey();
            stFriendUid = modelArrayList.get(inPosition).getUid();
            stFriendImage = modelArrayList.get(inPosition).getImage();
            stFriendName = modelArrayList.get(inPosition).getName();

        } else {
            ArrayList<ChatListData> modelArrayList = in.getParcelableArrayListExtra("data");
            inPosition = in.getIntExtra("position", 0);
            stChatKey = modelArrayList.get(inPosition).getChatKey();

        }
        //친구를 클릭했을때와 채팅 리스트에서 채팅 액티비티를 불러올 때 다르게 getintent를 설정해 줍니다
        //이유는 관련된 data가 다르기 때문입니다(FriendData / ChatListDate)


        showChatList(stChatKey);
        lastTextRef = database.getReference();
        //채팅 리스트를 보여줍니다
    }

    public void showChatList(final String stChatKey){
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference().child("chat").child(stChatKey).child("text");


        rvChat = (RecyclerView) findViewById(R.id.rvChat);
        mChatData = new ArrayList<>();

        //   mId = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
        rvChat.setLayoutManager(new LinearLayoutManager(this));
        //mRecyclerView.setItemAnimator(new SlideInOutLeftItemAnimator(mRecyclerView));
        mAdapter = new ChatAdapter(ChatActivity.this, mChatData, stMyUid);
        rvChat.setAdapter(mAdapter);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Log.d(TAG, "Value is: " + dataSnapshot);
                if (dataSnapshot.getValue() != null) {

                } else {

                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        myRef.addChildEventListener(new ChildEventListener() {
            //해당 addChildEventListener가 추가 되어 데이터 추가가 일어날때 마다 리사이클러뷰가 갱신됩니다
            //즉 채팅이 일어날때마다 추가 데이터를 불러옵니다
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot.getValue() == null || dataSnapshot.getValue().equals("")) {
                    rvChat.setVisibility(View.GONE);

                } else {
                    Log.d(TAG, "Requested"+ dataSnapshot.getValue().toString());
                    rvChat.setVisibility(View.VISIBLE);
                    ChatData model = dataSnapshot.getValue(ChatData.class);
                    mChatData.add(model);
                    rvChat.scrollToPosition(mChatData.size() - 1);
                    mAdapter.notifyItemInserted(mChatData.size() - 1);

                }
            }



            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }


        });


        final DatabaseReference checkRef = database.getReference().child("chat").child(stChatKey).child("chatUsers");
        checkRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //친구를 클릭하여 채팅창 개설시 나와 해당 친구의 정보를 채팅 데이터베이스에 업로드 합니다
                //이를 통해 이제 나와 해당 친구의 채팅 리스트에 이 채팅 창이 같이 표현됩니다

                if (!dataSnapshot.hasChild(stMyUid)) {

                    HashMap<String, Object> myInfo = new HashMap<>();
                    myInfo.put("image", stMyImage);
                    myInfo.put("name", stMyName);
                    myInfo.put("ok", "requested");
                    myInfo.put("chatKey", stChatKey);
                    myInfo.put("uid", stMyUid);

                    checkRef.child(stMyUid).setValue(myInfo);

                }
                if(!TextUtils.isEmpty(stFriendUid)) {
                    if (!dataSnapshot.hasChild(stFriendUid)) {
                        HashMap<String, Object> friendInfo = new HashMap<>();
                        friendInfo.put("image", stFriendImage);
                        friendInfo.put("name", stFriendName);
                        friendInfo.put("ok", "requested");
                        friendInfo.put("chatKey", stChatKey);
                        friendInfo.put("uid", stFriendUid);
                        checkRef.child(stFriendUid).setValue(friendInfo);
                    }
                }
                Log.d(TAG, "my info check called");

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void sendButtonClicked(View view){
        final String messageValue = editMessage.getText().toString().trim();
        //채팅 메세지를 입력하면 입력 날짜 순으로 데이터베이스에 업데이트 됩니다
        //이를 통해 데이터베이스 정보를 채팅 순서대로 불러 올 수 있습니다

        if (!TextUtils.isEmpty(messageValue)){

            Calendar c = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            final String stDate = sdf.format(c.getTime());

            HashMap<String, Object> messageInfo = new HashMap<>();
            messageInfo.put("image", stMyImage);
            messageInfo.put("name", stMyName);
            messageInfo.put("ok", "requested");
            messageInfo.put("id", stMyUid);
            messageInfo.put("text", messageValue);
            messageInfo.put("date", stDate);
            messageInfo.put("type", "message");
            myRef.child(stDate).setValue(messageInfo);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    HashMap<String, Object> lastMessageInfo = new HashMap<>();
                    lastMessageInfo.put("lastText", messageValue);
                    lastMessageInfo.put("lastDate", stDate);

                    //lastMessage는 채팅 창의 마지막 메세지를 보여주기 위해 같이 업로드 합니다
                    //누가 채팅을 치든 마지막 메세지가 지속적으로 해당 채팅 데이터베이스에 업로드 됩니다

                    lastTextRef.child("chat").child(stChatKey).child("lastMessage").setValue(lastMessageInfo);

                    editMessage.setText("");
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });



        }
    }

    @Override
    protected void onStart() {
        super.onStart();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_add){


            Intent in = new Intent(this, ChatInviteActivity.class);
            in.putExtra("chatKey", stChatKey);
            startActivityForResult(in, 1);

            //친구를 초대할 수 있습니다

        } else if(item.getItemId() == R.id.action_exit){
            exit();
            //채팅 창을 나갑니다

        }

        return super.onOptionsItemSelected(item);
    }

    public void exit(){
        exitRef = database.getReference().child("chat").child(stChatKey).child("chatUsers");
        exitRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Calendar c = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String stDate = sdf.format(c.getTime());

                Log.d(TAG, "User Count : "+dataSnapshot.getChildrenCount());

                if(dataSnapshot.getChildrenCount() > 1){

                    //아직 채팅 창에 2명 이상의 사람들이 있습니다
                    //채팅 창을 나가며 해당 채팅 데이터베이스에서 나의 유저정보를 지웁니다
                    //내가 나간다는 알림 메세지를 데이터에 업로드합니다
                    //이제 친구들이 내가 나간다는 것을 알 수 있습니다

                    exitRef.child(stMyUid).removeValue();
                    HashMap<String, Object> messageInfo = new HashMap<>();
                    messageInfo.put("image", stMyImage);
                    messageInfo.put("name", stMyName);
                    messageInfo.put("ok", "requested");
                    messageInfo.put("id", stMyUid);
                    messageInfo.put("text", "");
                    messageInfo.put("date", stDate);
                    messageInfo.put("type", "noti");
                    myRef.child(stDate).setValue(messageInfo);

                    Toast.makeText(ChatActivity.this, "Exiting This chat Group", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    //해당 채팅 창의 유저 숫자가 1명일 경우 채팅 창 자체를 삭제합니다
                    exitRef = database.getReference().child("chat").child(stChatKey);
                    exitRef.removeValue();
                    Toast.makeText(ChatActivity.this, "Exiting This chat Group", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode ==RESULT_OK && requestCode == 1){


            //친구 초대를 한 액티비티가 종료 돼면 새로운 채팅 키를 받아옵니다
            //새로 생성된 채팅 키를 바탕으로 채팅 리스트를 다시 불러옵니다.
            //즉 새로운 채팅 그룹을 위한 채팅 창이 화면에 보입니다
            stChatKey = data.getStringExtra("chatKey");

            if(!TextUtils.isEmpty(stChatKey)){
                showChatList(stChatKey);
            }


        }
    }


}
