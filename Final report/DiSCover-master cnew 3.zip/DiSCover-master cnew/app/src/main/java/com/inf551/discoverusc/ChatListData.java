package com.inf551.discoverusc;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 11/3/2017.
 */

public class ChatListData implements Parcelable{
    private String image;
    private String name;
    private String chatKey;
    private String ok;
    private String id;
    private String text;
    private Bitmap bitmap;
    private String lastText;
    private String lastDate;


    private List<String> names = new ArrayList<>();
    private List<String> images = new ArrayList<>();

    public ChatListData(){

    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChatKey() {
        return chatKey;
    }

    public void setChatKey(String chatKey) {
        this.chatKey = chatKey;
    }

    public String getOk() {
        return ok;
    }

    public void setOk(String ok) {
        this.ok = ok;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<String> getNames() {
        return names;
    }

    public void setNames(List<String> names) {
        this.names = names;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public String getLastText() {
        return lastText;
    }

    public void setLastText(String lastText) {
        this.lastText = lastText;
    }

    public String getLastDate() {
        return lastDate;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.image);
        dest.writeString(this.name);
        dest.writeString(this.chatKey);
        dest.writeString(this.ok);
        dest.writeString(this.id);
        dest.writeString(this.text);
        dest.writeParcelable(this.bitmap, flags);
        dest.writeString(this.lastText);
        dest.writeString(this.lastDate);
        dest.writeStringList(this.names);
        dest.writeStringList(this.images);
    }

    protected ChatListData(Parcel in) {
        this.image = in.readString();
        this.name = in.readString();
        this.chatKey = in.readString();
        this.ok = in.readString();
        this.id = in.readString();
        this.text = in.readString();
        this.bitmap = in.readParcelable(Bitmap.class.getClassLoader());
        this.lastText = in.readString();
        this.lastDate = in.readString();
        this.names = in.createStringArrayList();
        this.images = in.createStringArrayList();
    }

    public static final Creator<ChatListData> CREATOR = new Creator<ChatListData>() {
        @Override
        public ChatListData createFromParcel(Parcel source) {
            return new ChatListData(source);
        }

        @Override
        public ChatListData[] newArray(int size) {
            return new ChatListData[size];
        }
    };
}
