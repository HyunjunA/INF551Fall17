package com.inf551.discoverusc;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Transformation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by idahan on 2016. 12. 29..
 */

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {
    final String TAG = this.getClass().getSimpleName();
    private List<ChatData> mChatData;
    private static final long MINUTE_MILLIS = 1000 * 60;
    private static final long HOUR_MILLIS = 60 * MINUTE_MILLIS;
    private static final long DAY_MILLIS = 24 * HOUR_MILLIS;
    private static SimpleDateFormat sDateFormat = new SimpleDateFormat("dd MMM");

    private Context context;
    String stEmail;
    String stUid;
    Transformation transformation;
    FirebaseDatabase database;
    DatabaseReference myRef;
    String mId;

    private static final int CHAT_RIGHT = 1;
    private static final int CHAT_LEFT = 2;

    public ChatAdapter(Context context, List<ChatData> mChatData, String mId) {
        this.mChatData = mChatData;
        this.context = context;
        this.mId = mId;
    }
    @Override
    public int getItemViewType(int position) {

        if(mChatData.get(position).getId()!= null) {
            if (mChatData.get(position).getId().equals(mId)) {
                return CHAT_RIGHT;
            }
        }
        return CHAT_LEFT;
    }

    @Override
    public ChatAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v;

        if (viewType == CHAT_RIGHT) {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_bubble_right, parent, false);
        } else {
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_bubble_left, parent, false);
        }

        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        SharedPreferences sharedPreferences1 = context.getSharedPreferences("user_info", MODE_PRIVATE);
        stEmail = sharedPreferences1.getString("email", "");
        stUid = sharedPreferences1.getString("uid", "");


        if(mChatData.get(position).getType().equals("noti")){
            holder.tvNoti.setVisibility(View.VISIBLE);
            holder.tvNoti.setText(mChatData.get(position).getName()+ " exit");
            holder.chatView.setVisibility(View.GONE);
        } else {
            holder.tvNoti.setVisibility(View.INVISIBLE);
            holder.chatView.setVisibility(View.VISIBLE);
        }

        holder.tvMessage.setText(mChatData.get(position).getText());
        holder.tvSender.setText(mChatData.get(position).getName());

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date getDate = null;
        try {
            getDate = sdf.parse(mChatData.get(position).getDate());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long dateMillis = getDate.getTime();
        String date = "";
        long now = System.currentTimeMillis();

        // Change how the date is displayed depending on whether it was written in the last minute,
        // the hour, etc.
        if (now - dateMillis < (DAY_MILLIS)) {
            if (now - dateMillis < (HOUR_MILLIS)) {
                long minutes = Math.round((now - dateMillis) / MINUTE_MILLIS);
                date = String.valueOf(minutes) + "m";
            } else {
                long minutes = Math.round((now - dateMillis) / HOUR_MILLIS);
                date = String.valueOf(minutes) + "h";
            }
        } else {
            Date dateDate = new Date(dateMillis);
            date = sDateFormat.format(dateDate);
        }

        // Add a dot to the date string
        date = "\u2022 " + date;

        holder.tvDate.setText(date);



        Glide.with(context)
                .load(mChatData.get(position).getImage())
                .apply(RequestOptions.circleCropTransform())
                .into(holder.ivUser);

    }



 @Override
    public int getItemCount() {
        return mChatData.size();
    }


   public class ViewHolder extends RecyclerView.ViewHolder {


       ImageView ivUser;
       TextView tvMessage;
       TextView tvSender;
       TextView tvDate;
       RelativeLayout chatView;
       TextView tvNoti;


       public ViewHolder(final View itemView) {
            super(itemView);

           ivUser = (ImageView) itemView.findViewById(R.id.ivUser);
           tvMessage = (TextView) itemView.findViewById(R.id.tvMessage);
           tvSender = (TextView)itemView.findViewById(R.id.tvSender);
           tvDate = (TextView)itemView.findViewById(R.id.tvDate);
           chatView = (RelativeLayout)itemView.findViewById(R.id.chatView);
           tvNoti = (TextView)itemView.findViewById(R.id.tvNoti);
       }


    }


}
