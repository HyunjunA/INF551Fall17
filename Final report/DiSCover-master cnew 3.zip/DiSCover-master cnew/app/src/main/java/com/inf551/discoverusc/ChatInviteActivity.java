package com.inf551.discoverusc;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChatInviteActivity extends AppCompatActivity implements ChatInviteAdapter.MyAdapterOnClickHandler {
    final String TAG = getClass().getSimpleName();
    FirebaseDatabase database;
    DatabaseReference myRef;
    private ValueEventListener mValueEventListener;

    DatabaseReference chatListRef;
    private ValueEventListener mChatListEventListener;

    String stMyUid;
    private RecyclerView mRecyclerView;
    private ChatInviteAdapter mChatInviteAdapter;
    private LinearLayoutManager mLayoutManager;
    ArrayList<FriendData> friendDataArrayList;
    ArrayList<String> chatKeyList;
    String stChatKey;

    List<String> chatUserNameList;
    List<String> chatUserImageList;
    List<String> chatUserIdList;

    Boolean friendCheck = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_invite);
        database = FirebaseDatabase.getInstance();
        SharedPreferences sharedPref = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        stMyUid = sharedPref.getString("myId", "");
        Log.d(TAG, "My id: "+stMyUid);


        mRecyclerView = (RecyclerView) findViewById(R.id.rvFriend);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);

        mRecyclerView.setLayoutManager(mLayoutManager);

        chatKeyList = new ArrayList<>();
        showFriendList();

        //이전 액티비티에서 chat key를 받아 옵니다
        Intent in = getIntent();
        stChatKey = in.getStringExtra("chatKey");


    }

    public void showFriendList(){
        friendDataArrayList = new ArrayList<>();

        mChatInviteAdapter = new ChatInviteAdapter(this, this, friendDataArrayList);
        mRecyclerView.setAdapter(mChatInviteAdapter);

        showFriends();
        //friend activity와 동일하하게 친구 리스트를 받아 옵니다

    }
    public void showFriends(){

        if( mValueEventListener != null){
            myRef.removeEventListener(mValueEventListener);
        }

        myRef = database.getReference("friends").child(stMyUid);
        //내 id를 가지고 친구 목록을 불러 옵니다
        if(mValueEventListener == null){
            mValueEventListener =  new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    friendDataArrayList.clear();
                    for (DataSnapshot friendData : dataSnapshot.getChildren()) {
                        Log.d(TAG, "friendDataData" + friendData.getValue().toString());
                        FriendData model = friendData.getValue(FriendData.class);
                        friendDataArrayList.add(model);
                        //내 친구 목록을 FriendData에 저장하고 이를 array list에 추가합니다
                    }
                    Log.d(TAG,"downLoadFinished");
                    if (!dataSnapshot.exists()){
                        Log.d(TAG,"noData");
                        Toast.makeText(ChatInviteActivity.this, "You have no friend", Toast.LENGTH_SHORT).show();
                    }

                    mChatInviteAdapter.swapData(friendDataArrayList);
                    //adapter의 swapdata 메소드를 이용해서 데이터를 갱신해 줍니다.
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {



                }
            };
        }
        myRef.addListenerForSingleValueEvent(mValueEventListener);
    }

    @Override
    public void onClick(String photoUrl, ArrayList<FriendData> modelArrayList, int adapterPosition) {
//        Toast.makeText(this,"id : "+modelArrayList.get(adapterPosition).getUid(), Toast.LENGTH_SHORT).show();
        final String stInvitedUid = modelArrayList.get(adapterPosition).getUid();
        final String stInvitedName = modelArrayList.get(adapterPosition).getName();
        final String stInvitedImage = modelArrayList.get(adapterPosition).getImage();

        final String stFriendUid = modelArrayList.get(adapterPosition).getUid();
        DatabaseReference blockRef = database.getReference("friends").child(stFriendUid);
        blockRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d(TAG, "Ok Succeeded");
                if(dataSnapshot.hasChild(stMyUid)){
                    String stOk = dataSnapshot.child(stMyUid).child("ok").getValue().toString();
                    Log.d(TAG, "Your friend added you : "+stOk);
                    //친구가 나를 추가한 상태인지 확인합니다
                    //이를 통해 친구가 나를 차단했는지 확인합니다
                    if(stOk.equals("blocked")){
                        Toast.makeText(ChatInviteActivity.this, "Chat Request Denied", Toast.LENGTH_SHORT).show();
                    } else {
                        //그렇지 않을 경우 채팅창으로 초대 합니다
                        inviteToChat(stInvitedUid, stInvitedName, stInvitedImage);
                    }
                } else {
                    //해당 친구는 나를 친추하지 않았습니다 마음껏 초대합니다
                    inviteToChat(stInvitedUid, stInvitedName, stInvitedImage);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

    }

    public void getExistingUsers(){


        if( mChatListEventListener != null){
            chatListRef.removeEventListener(mChatListEventListener);
        }
        chatListRef = database.getReference("chat").child(stChatKey).child("chatUsers");

        if(mChatListEventListener == null){
            mChatListEventListener =  new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    for (DataSnapshot allData : dataSnapshot.getChildren()) {
//                       Log.d(TAG, "chatUserData" + allData.child("chatUsers").getValue().toString() + ", count : " + allData.getChildrenCount());
                        chatUserIdList.add(allData.getKey());
                        chatUserNameList.add(allData.child("name").getValue().toString());
                        chatUserImageList.add(allData.child("image").getValue().toString());
                        //새 친구를 추가한 리스트에 기존 친구들을 추가했습니다

                    }

                    DatabaseReference newChatRef = database.getReference();
                    String stNewChatKey = newChatRef.child("chat").push().getKey();
                    DatabaseReference checkRef = database.getReference().child("chat").child(stNewChatKey).child("chatUsers");
                    if(chatUserNameList.size() != 0){
                        Log.d(TAG, chatUserNameList.toString());
                        for(int i=0; i<chatUserNameList.size();i++){
                            HashMap<String, Object> friendInfo = new HashMap<>();
                            friendInfo.put("uid", chatUserIdList.get(i));
                            friendInfo.put("name", chatUserNameList.get(i));
                            friendInfo.put("image", chatUserImageList.get(i));
                            friendInfo.put("ok", "requested");
                            friendInfo.put("chatKey", stNewChatKey);
                            checkRef.child(chatUserIdList.get(i)).setValue(friendInfo);

                        }
                    }
                    //해당 자료를 가지고 이제 새로운 채팅창을 만듭니다
                    //채팅창에 관련 유저 정보를 for 루프를 통해 입력해 줍니다

                    Toast.makeText(ChatInviteActivity.this, "New Chat Group Created", Toast.LENGTH_SHORT).show();
                    //종료 전 새로운 채팅 키 데이터를 저장해줍니다
                    //이제 종료 시 ChatActivity에서 새로운 채팅 키를 받아서 새 채팅 창을 엽니다
                    Intent data = new Intent();
                    data.putExtra("chatKey", stNewChatKey);
                    setResult(RESULT_OK, data);
                    finish();

                }
                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            };
        }
        chatListRef.addListenerForSingleValueEvent(mChatListEventListener);
    }


    public void inviteToChat(final String stInvitedUid, final String stInvitedName, final String stInvitedImage){
        final DatabaseReference checkRef = database.getReference().child("chat").child(stChatKey).child("chatUsers");
        checkRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if(!TextUtils.isEmpty(stInvitedUid)) {
                    if (!dataSnapshot.hasChild(stInvitedUid)) {

                        chatUserNameList = new ArrayList<>();
                        chatUserImageList = new ArrayList<>();
                        chatUserIdList = new ArrayList<>();

                        chatUserIdList.add(stInvitedUid);
                        chatUserImageList.add(stInvitedImage);
                        chatUserNameList.add(stInvitedName);
                        //새로운 채팅창을 만들기 위해 새로운 채팅창에 합류할 유저 리스트를 만듭니다
                        //우선 새로 초대하는 친구의 정보를 리스트에 추가합니다
                        //이후 해당 리스트에 기존 유저들을 추가하는 메소드를 부릅니다
                        getExistingUsers();

                    }   else {
                        Toast.makeText(ChatInviteActivity.this, "This friend already joined your chat", Toast.LENGTH_SHORT).show();
                    }
                }
                Log.d(TAG, "my info check called");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
