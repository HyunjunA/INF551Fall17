package com.inf551.discoverusc;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by idahan on 2017. 9. 9..
 */

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ViewHolder> {
    String TAG = getClass().getSimpleName();
    private Context context;
    ArrayList<ChatListData> modelArrayList;
    private MyAdapterOnClickHandler mClickHandler;

    List<String> imageList;
    private static final long MINUTE_MILLIS = 1000 * 60;
    private static final long HOUR_MILLIS = 60 * MINUTE_MILLIS;
    private static final long DAY_MILLIS = 24 * HOUR_MILLIS;
    private static SimpleDateFormat sDateFormat = new SimpleDateFormat("dd MMM");

    String stMyImage;
    /**
     * The interface that receives onClick messages.
     */
    public interface MyAdapterOnClickHandler {
        void onChatListClick(String photoUrl, ArrayList<ChatListData> modelArrayList, int adapterPosition);
    }

    /**
     * Creates a ForecastAdapter.
     *
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */
    public ChatListAdapter(MyAdapterOnClickHandler clickHandler, Context context, ArrayList<ChatListData> modelArrayList, String stMyImage) {
        mClickHandler = clickHandler;
        this.modelArrayList = modelArrayList;
        this.context = context;
        this.stMyImage = stMyImage;

    }

    /**
     * Cache of the children views for a forecast list item.
     */


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView ivImage;

        public TextView tvName;
        public TextView tvDate;
        public TextView tvMessage;

        public ViewHolder(View v) {
            super(v);
            ivImage = (ImageView) v.findViewById(R.id.ivImage);
            tvName = (TextView) v.findViewById(R.id.tvName);
            tvDate = (TextView) v.findViewById(R.id.tvDate);
            tvMessage = (TextView) v.findViewById(R.id.tvMessage);
            v.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            String stPhotoUrl = modelArrayList.get(adapterPosition).getImage();

            mClickHandler.onChatListClick(stPhotoUrl, modelArrayList, adapterPosition);

        }
    }
    @Override
    public ChatListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                         int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat_list, parent, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {




//        Bitmap bitmap = modelArrayList.get(position).getBitmap();
        imageList = modelArrayList.get(position).getImages();
        final Bitmap[] bitmaps = new Bitmap[imageList.size()];


        //유저 수에 맞게 case를 구별 합니다
        switch (imageList.size()){

            case 1:
                Glide.with(context)
                        .load(R.mipmap.default_image)
                        .apply(RequestOptions.circleCropTransform())
                        .into(holder.ivImage);
                break;

            case 2:
                if(imageList.get(0).equals(stMyImage)){
                    Glide.with(context)
                            .load(imageList.get(1))
                            .apply(RequestOptions.circleCropTransform())
                            .apply(new RequestOptions()
                                    .placeholder(R.mipmap.default_image))
                            .into(holder.ivImage);

                } else {
                    Glide.with(context)
                            .load(imageList.get(0))
                            .apply(RequestOptions.circleCropTransform())
                            .apply(new RequestOptions()
                                    .placeholder(R.mipmap.default_image))
                            .into(holder.ivImage);
                }
                break;
            case 3:
                final List<String> newImageList = new ArrayList<>();
                for (int i = 0; i < imageList.size(); i++) {
                    if (!imageList.get(i).equals(stMyImage)) {
                        newImageList.add(imageList.get(i));
                    }
                }
                //Glide로 각각의 유저의 이미지를 bitmap으로 로드합니다
                //불러온 비트맵은 캔버스 기능을 이용해 하나의 이미지로 합칩니다
                //이미지 list 숫자에 따라 glide onResourceReady의 숫자만 다르지 구조는 똑같습니다
                //for 루프를 사용하면 bitmap을 받아오기 전에 다음 으로 넘어가 실질적으로 이미지 합성이 이루어 지지 않습니다
                // 때문에 좀 무식하긴 하지만 아래와 같이 작성했습니다
                //4명까지는 원을 4등분하여 프로필 이미지가 합성되고 그 이상 부터는 추가로 합성되지는 않습니다
                Glide.with(context)
                        .asBitmap()
                        .load(newImageList.get(0))
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                bitmaps[0] = resource;
                                Glide.with(context)
                                        .asBitmap()
                                        .load(newImageList.get(1))
                                        .into(new SimpleTarget<Bitmap>() {
                                            @Override
                                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                                bitmaps[1] = resource;
                                                Bitmap merged = combineImages(bitmaps[0], bitmaps[1]);
                                                Glide.with(context)
                                                        .load(merged)
                                                        .apply(RequestOptions.circleCropTransform())
                                                        .into(holder.ivImage);

                                            }
                                        });
                            }
                        });
                break;
            case 4:
                final List<String> newImageList2 = new ArrayList<>();
                for (int i = 0; i < imageList.size(); i++) {
                    if (!imageList.get(i).equals(stMyImage)) {
                        newImageList2.add(imageList.get(i));
                    }
                }
                Glide.with(context)
                        .asBitmap()
                        .load(newImageList2.get(0))
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                bitmaps[0] = resource;
                                Glide.with(context)
                                        .asBitmap()
                                        .load(newImageList2.get(1))
                                        .into(new SimpleTarget<Bitmap>() {
                                            @Override
                                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                                bitmaps[1] = resource;
                                                Glide.with(context)
                                                        .asBitmap()
                                                        .load(newImageList2.get(2))
                                                        .into(new SimpleTarget<Bitmap>() {
                                                            @Override
                                                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                                                bitmaps[2] = resource;
                                                                Bitmap merged = tripleImages(bitmaps[0], bitmaps[1], bitmaps[2]);
                                                                Glide.with(context)
                                                                        .load(merged)
                                                                        .apply(RequestOptions.circleCropTransform())
                                                                        .into(holder.ivImage);
                                                            }
                                                        });

                                            }
                                        });
                            }
                        });
                Log.d(TAG, "newImageList2 : "+newImageList2.size()+", bitmap size : "+bitmaps.length);
                break;
            default:
                final List<String> newImageList3 = new ArrayList<>();
                for (int i = 0; i < imageList.size(); i++) {
                    if (!imageList.get(i).equals(stMyImage)) {
                        newImageList3.add(imageList.get(i));
                    }
                }
                Glide.with(context)
                        .asBitmap()
                        .load(newImageList3.get(0))
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                bitmaps[0] = resource;
                                Glide.with(context)
                                        .asBitmap()
                                        .load(newImageList3.get(1))
                                        .into(new SimpleTarget<Bitmap>() {
                                            @Override
                                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                                bitmaps[1] = resource;
                                                Glide.with(context)
                                                        .asBitmap()
                                                        .load(newImageList3.get(2))
                                                        .into(new SimpleTarget<Bitmap>() {
                                                            @Override
                                                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                                                bitmaps[2] = resource;
                                                                Glide.with(context)
                                                                        .asBitmap()
                                                                        .load(newImageList3.get(3))
                                                                        .into(new SimpleTarget<Bitmap>() {
                                                                            @Override
                                                                            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                                                                bitmaps[3] = resource;
                                                                                Bitmap merged = quarterImages(bitmaps[0], bitmaps[1], bitmaps[2], bitmaps[3]);
                                                                                Glide.with(context)
                                                                                        .load(merged)
                                                                                        .apply(RequestOptions.circleCropTransform())
                                                                                        .into(holder.ivImage);
                                                                            }
                                                                        });
                                                            }
                                                        });

                                            }
                                        });
                            }
                        });

                Log.d(TAG, "newImageList3 : "+newImageList3.size()+", bitmap size : "+bitmaps.length);
                break;

        }







        List<String> nameList = modelArrayList.get(position).getNames();
        String stNames = nameList.get(0);
        for(int i=1; i < nameList.size(); i++){
            stNames += ", " +nameList.get(i);
        }


        holder.tvName.setText(stNames);
        holder.tvMessage.setText("\""+modelArrayList.get(position).getLastText()+"\"");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date getDate = null;
        if(!TextUtils.isEmpty(modelArrayList.get(position).getLastDate())){
            try {
                getDate = sdf.parse(modelArrayList.get(position).getLastDate());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long dateMillis = getDate.getTime();
            String date = "";
            long now = System.currentTimeMillis();

            // Change how the date is displayed depending on whether it was written in the last minute,
            // the hour, etc.
            if (now - dateMillis < (DAY_MILLIS)) {
                if (now - dateMillis < (HOUR_MILLIS)) {
                    long minutes = Math.round((now - dateMillis) / MINUTE_MILLIS);
                    date = String.valueOf(minutes) + "m";
                } else {
                    long minutes = Math.round((now - dateMillis) / HOUR_MILLIS);
                    date = String.valueOf(minutes) + "h";
                }
            } else {
                Date dateDate = new Date(dateMillis);
                date = sDateFormat.format(dateDate);
            }

            // Add a dot to the date string
            date = "\u2022 " + date;

            holder.tvDate.setText(date);

        }

    }
    @Override
    public int getItemCount() {
        if (null == modelArrayList) return 0;
            return modelArrayList.size();
    }

    public void swapData(ArrayList<ChatListData> arrayList) {

        modelArrayList = arrayList;
        notifyDataSetChanged();
    }

    //아래는 캔버스 기능을 통해 비트맵을 조합하는 코드 들입니다
    public Bitmap combineImages(Bitmap c, Bitmap s) {
        Bitmap cs = null;

        int width, height = 0;

        if(c.getWidth() > s.getWidth()) {
            width = c.getWidth()* 2;
            height = c.getHeight() ;
        } else {
            width = s.getWidth()* 2;
            height = s.getHeight();
        }


        cs = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        Canvas comboImage = new Canvas(cs);

        Rect dest1 = new Rect(0, 0, width/2, height); // left,top,right,bottom
        comboImage.drawBitmap(c, null, dest1, null);

        Rect dest2 = new Rect(width/2, 0, width, height); // left,top,right,bottom
        comboImage.drawBitmap(s, null, dest2, null);

        return cs;
    }
    public Bitmap tripleImages(Bitmap a, Bitmap b, Bitmap c) {
        Bitmap cs = null;

        int width, height = 0;

        if(a.getWidth() > b.getWidth()) {
            width = a.getWidth()* 2;
            height = a.getHeight() ;
        } else {
            width = b.getWidth()* 2;
            height = b.getHeight();
        }
        cs = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas comboImage = new Canvas(cs);
        Rect dest1 = new Rect(0, 0, width/2, height); // left,top,right,bottom
        comboImage.drawBitmap(a, null, dest1, null);
        Rect dest2 = new Rect(width/2, 0, width, height/2); // left,top,right,bottom
        comboImage.drawBitmap(b, null, dest2, null);
        Rect dest3 = new Rect(width/2, height/2, width, height); // left,top,right,bottom
        comboImage.drawBitmap(c, null, dest3, null);
        return cs;
    }
    public Bitmap quarterImages(Bitmap a, Bitmap b, Bitmap c, Bitmap d) {
        Bitmap cs = null;

        int width, height = 0;

        if(a.getWidth() > b.getWidth()) {
            width = a.getWidth()* 2;
            height = a.getHeight() ;
        } else {
            width = b.getWidth()* 2;
            height = b.getHeight();
        }
        cs = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas comboImage = new Canvas(cs);
        Rect dest1 = new Rect(0, 0, width/2, height); // left,top,right,bottom
        comboImage.drawBitmap(a, null, dest1, null);
        Rect dest2 = new Rect(width/2, 0, width, height/2); // left,top,right,bottom
        comboImage.drawBitmap(b, null, dest2, null);
        Rect dest3 = new Rect(width/2, height/2, width, height); // left,top,right,bottom
        comboImage.drawBitmap(c, null, dest3, null);

        Rect dest4 = new Rect(0, height/2, width/2, height); // left,top,right,bottom
        comboImage.drawBitmap(d, null, dest4, null);
        return cs;
    }
}
