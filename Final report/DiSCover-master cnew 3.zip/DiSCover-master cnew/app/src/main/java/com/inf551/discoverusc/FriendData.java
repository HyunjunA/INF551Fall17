package com.inf551.discoverusc;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by idahan on 2017. 11. 18..
 */

public class FriendData implements Parcelable {
    private String image;
    private String name;
    private String ok;
    private String chatKey;
    private String uid;


    public FriendData(){

    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOk() {
        return ok;
    }

    public void setOk(String ok) {
        this.ok = ok;
    }


    public String getChatKey() {
        return chatKey;
    }

    public void setChatKey(String chatKey) {
        this.chatKey = chatKey;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.image);
        dest.writeString(this.name);
        dest.writeString(this.ok);
        dest.writeString(this.chatKey);
        dest.writeString(this.uid);
    }

    protected FriendData(Parcel in) {
        this.image = in.readString();
        this.name = in.readString();
        this.ok = in.readString();
        this.chatKey = in.readString();
        this.uid = in.readString();
    }

    public static final Creator<FriendData> CREATOR = new Creator<FriendData>() {
        @Override
        public FriendData createFromParcel(Parcel source) {
            return new FriendData(source);
        }

        @Override
        public FriendData[] newArray(int size) {
            return new FriendData[size];
        }
    };
}
